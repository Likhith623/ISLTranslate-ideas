"""Complete landmark-to-text network; PCAT is the only temporal compressor."""
import torch
from torch import Tensor, nn
from .config import ModelConfig
from .geometry import BodyFrame
from .operators import ProgressCoupledAreaTransport
from .tokenizer import ByteTokenizer, Utf8Constraint


class SignTranslator(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        cfg.validate()
        self.cfg = cfg
        self.frame = BodyFrame(cfg.anchors, cfg.anchor_min_confidence, cfg.anchor_policy)
        # Affine region maps preserve linear interpolation, unlike a pointwise MLP.
        self.region_maps = nn.ModuleList([nn.Linear(4 * len(r), cfg.rank) for r in cfg.regions])
        self.operator = ProgressCoupledAreaTransport(
            len(cfg.regions) * cfg.rank, cfg.bins, cfg.width, cfg.metric_floor,
            cfg.clock, cfg.operator, cfg.timing, cfg.progress_scales,
            cfg.progress_augmentation, cfg.metric_condition_limit, cfg.integration, cfg.integration_precision)
        self.source_position = nn.Parameter(torch.empty(1, self.operator.token_count, cfg.width))
        self.target_position = nn.Parameter(torch.empty(1, cfg.max_target_length, cfg.width))
        nn.init.normal_(self.source_position, std=0.02)
        nn.init.normal_(self.target_position, std=0.02)
        encoder_layer = nn.TransformerEncoderLayer(
            cfg.width, cfg.heads, cfg.width * cfg.ff_multiplier, cfg.dropout,
            activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(encoder_layer, cfg.encoder_layers,
                                             norm=nn.LayerNorm(cfg.width), enable_nested_tensor=False)
        decoder_layer = nn.TransformerDecoderLayer(
            cfg.width, cfg.heads, cfg.width * cfg.ff_multiplier, cfg.dropout,
            activation="gelu", batch_first=True, norm_first=True)
        self.decoder = nn.TransformerDecoder(decoder_layer, cfg.decoder_layers, norm=nn.LayerNorm(cfg.width))
        self.embedding = nn.Embedding(ByteTokenizer.vocab_size, cfg.width, padding_idx=0)
        self.output = nn.Linear(cfg.width, ByteTokenizer.vocab_size, bias=False)

    def canonical_features(self, pose: Tensor, confidence: Tensor, lengths: Tensor) -> Tensor:
        if pose.ndim != 4 or pose.shape[2:] != (self.cfg.joints, 3):
            raise ValueError("pose layout does not match config")
        if confidence.shape != pose.shape[:-1]:
            raise ValueError("confidence shape mismatch")
        b, t = pose.shape[:2]
        if lengths.shape != (b,) or lengths.dtype not in (torch.int32, torch.int64):
            raise ValueError("lengths must be an integer vector [B]")
        if ((lengths < 2) | (lengths > t)).any():
            raise ValueError("invalid sequence lengths")
        valid = torch.arange(t, device=pose.device)[None] < lengths[:, None]
        if not torch.isfinite(pose[valid]).all() or not torch.isfinite(confidence[valid]).all():
            raise ValueError("valid positions must be finite; impute missing joints in the loader")
        if ((confidence[valid] < 0) | (confidence[valid] > 1)).any():
            raise ValueError("confidence outside [0,1]")
        pose = torch.where(valid[..., None, None], pose, 0)
        confidence = torch.where(valid[..., None], confidence, 0)
        coords = self.frame(pose, confidence, lengths)
        return torch.where(valid[..., None, None], torch.cat((coords, confidence[..., None]), dim=-1), 0)

    def embed_features(self, features):
        blocks = [mapping(features[:, :, region].flatten(2))
                  for mapping, region in zip(self.region_maps, self.cfg.regions)]
        return torch.cat(blocks, dim=-1)

    def embed_pose(self, pose: Tensor, confidence: Tensor, lengths: Tensor) -> Tensor:
        return self.embed_features(self.canonical_features(pose, confidence, lengths))

    def encode(self, pose: Tensor, confidence: Tensor, lengths: Tensor,
               timestamps: Tensor | None = None) -> Tensor:
        """Return memory; use encode_with_mask when detail memory includes padding."""
        return self.encode_with_mask(pose, confidence, lengths, timestamps)[0]

    def encode_invariant(self, pose, confidence, lengths, timestamps=None):
        if self.cfg.timing or self.cfg.operator == "temporal":
            raise ValueError("invariant encoding requires timing=false and progress cells")
        z = self.embed_pose(pose, confidence, lengths)
        tokens = self.operator(z, lengths, timestamps)
        return self.encoder(tokens + self.source_position)

    def encode_with_mask(self, pose, confidence, lengths, timestamps=None):
        features = self.canonical_features(pose, confidence, lengths)
        z = self.embed_features(features)
        tokens = self.operator(z, lengths, timestamps)
        coarse = self.encoder(tokens + self.source_position)
        mask = torch.zeros(coarse.shape[:2], dtype=torch.bool, device=coarse.device)
        if not self.cfg.detail_memory:
            return coarse, mask
        b, t = features.shape[:2]
        valid = torch.arange(t, device=pose.device)[None] < lengths[:, None]
        d = torch.where(valid[:, 1:, None], z[:, 1:] - z[:, :-1], 0)
        ell = torch.linalg.vector_norm(d * self.operator.metric.sqrt(), dim=-1)
        progress = torch.cat((z.new_zeros(b, 1), ell.cumsum(1)), dim=1)
        total = ell.sum(1, keepdim=True)
        progress = progress / torch.where(total > 0, total, 1)
        # The exact canonical vector is a reserved, unprojected subspace of
        # memory. Position and optional duration occupy disjoint coordinates.
        frequency = torch.arange(1, self.cfg.detail_position_dim // 2 + 1, device=z.device, dtype=z.dtype)
        phase = torch.pi * progress[..., None] * frequency
        position = torch.cat((phase.sin(), phase.cos()), -1)
        if self.cfg.timing:
            if timestamps is None:
                raise ValueError("timing-enabled detail memory requires timestamps in seconds")
            ts = torch.where(valid, timestamps.to(z), 0)
            ts = ts - ts[:, :1]
            duration = ts.gather(1, (lengths - 1)[:, None])
            timing = torch.stack((torch.log1p(ts.clamp_min(0)), ts / duration), -1)
        else:
            timing = z.new_zeros(b, t, 2)
        detail = torch.cat((features.flatten(2).to(z.dtype), position, timing), -1)
        detail = torch.nn.functional.pad(detail, (0, self.cfg.width - detail.shape[-1]))
        detail = torch.where(valid[..., None], detail, 0)
        return torch.cat((coarse, detail), 1), torch.cat((mask, ~valid), 1)

    def decode(self, decoder_input: Tensor, memory: Tensor, memory_padding_mask: Tensor | None = None) -> Tensor:
        length = decoder_input.shape[1]
        if length < 1 or length > self.cfg.max_target_length:
            raise ValueError("decoder length outside configured bounds")
        hidden = self.embedding(decoder_input) + self.target_position[:, :length]
        causal = torch.ones(length, length, device=hidden.device, dtype=torch.bool).triu(1)
        hidden = self.decoder(hidden, memory, tgt_mask=causal,
                              memory_key_padding_mask=memory_padding_mask,
                              tgt_key_padding_mask=decoder_input.eq(ByteTokenizer.pad_id))
        return self.output(hidden)

    def forward(self, pose, confidence, lengths, decoder_input, timestamps=None):
        memory, mask = self.encode_with_mask(pose, confidence, lengths, timestamps)
        return self.decode(decoder_input, memory, mask)

    @torch.no_grad()
    def generate(self, pose, confidence, lengths, timestamps=None, max_new_tokens=None):
        if self.training:
            raise RuntimeError("call model.eval() before deterministic generation")
        limit = self.cfg.max_target_length if max_new_tokens is None else max_new_tokens
        if type(limit) is not int or not 1 <= limit <= self.cfg.max_target_length:
            raise ValueError("invalid generation length")
        memory, memory_mask = self.encode_with_mask(pose, confidence, lengths, timestamps)
        ids = torch.full((pose.shape[0], 1), ByteTokenizer.bos_id, dtype=torch.long, device=pose.device)
        finished = torch.zeros(pose.shape[0], device=pose.device, dtype=torch.bool)
        constraint = Utf8Constraint(pose.shape[0], pose.device)
        for step in range(limit):
            logits = self.decode(ids, memory, memory_mask)[:, -1]
            logits = constraint.mask(logits, limit - step)
            next_id = logits.argmax(-1)
            next_id = torch.where(finished, ByteTokenizer.pad_id, next_id)
            ids = torch.cat((ids, next_id[:, None]), dim=1)
            finished = finished | next_id.eq(ByteTokenizer.eos_id)
            constraint.advance(next_id, finished)
            if finished.all():
                break
        return ids
