"""Translate a single canonical 3D landmark NPZ with trained weights."""
import argparse
import torch
from .data import load_pose
from .runtime import load_checkpoint, resolve_device
from .tokenizer import ByteTokenizer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--pose", required=True)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--max-new-tokens", type=int)
    args = parser.parse_args()
    device = resolve_device(args.device)
    model, cfg, _ = load_checkpoint(args.checkpoint, device)
    sample = load_pose(args.pose, cfg.model, cfg.data.max_frames)
    model.eval()
    ids = model.generate(sample["pose"][None].to(device), sample["confidence"][None].to(device),
                         torch.tensor([len(sample["pose"])], device=device),
                         sample["timestamps"][None].to(device), args.max_new_tokens)
    print(ByteTokenizer().decode(ids[0]))


if __name__ == "__main__":
    main()
