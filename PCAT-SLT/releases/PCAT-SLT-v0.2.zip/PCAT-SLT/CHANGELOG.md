# Changes

## 0.2.0

Implemented exact prefix-area interval extraction with a clipping oracle/fallback, shared-clock multiscale tokens, normalized-progress augmentation, bounded metric conditioning, optional unprojected full-frame detail/timing memory, padding-safe reference fallback and strict UTF-8 generation. Added exact source-group leakage checks, selectable float64 integration, matched configuration controls, expanded proofs and a limitation-by-limitation audit.

Checkpoint format is now 2. Version 0.1 weights require the preserved original source release because the metric parameterization changed. Existing historical run weights/data were not overwritten. Original verification artifacts are retained under `reports/v1/`.

The current source remains a research implementation with CPU evidence and synthetic sanity experiments. No real-corpus SOTA or publication-level novelty claim has been added.
