# PCAT-SLT v0.2

**Multiscale Progress-Coupled Area Transport**, with a detail-preserving encoder path and valid UTF-8 generation.

This is a complete PyTorch **3D-landmark-to-text** research project. V0.2 addresses concrete defects in the initial architecture; it is not a claim of perfect translation, verified SOTA performance or guaranteed publication-level novelty.

## What changed

- **Exact prefix integration:** shares one path-prefix calculation across progress windows/scales; a separately implemented clipping backend remains available.
- **Multiscale area transport:** whole-clip and local cells retain order interactions that can straddle fine-cell boundaries.
- **Progress augmentation:** distinguishes some retraced-motion paths that collided in the original one-cell representation.
- **Bounded metric conditioning:** prevents arbitrary clock anisotropy, rather than relying only on a positive floor.
- **Uncompressed detail memory:** the enhanced model exposes every valid frame's complete canonical coordinates/confidence and optional timing directly to decoder cross-attention.
- **Reliable-reference fallback:** handles an occluded initial body frame when a later reliable reference is available.
- **Constrained UTF-8 generation:** prevents malformed byte sequences and incomplete code points at the token limit.
- **Source-group leakage checks:** use `source_video`/`split_group` when supplied, in addition to ID, path and content checks.

The mathematical primitives have substantial prior art. The research hypothesis remains whether the specified common-progress area **transport** helps SLT relative to matched signature and identity-transport baselines. Read [ARCHITECTURE.md](ARCHITECTURE.md), [docs/LITERATURE.md](docs/LITERATURE.md) and [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

## Quick start

Python 3.10+, run from the extracted project root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
pytest -q
ruff check .

pcat-demo-data --output data/demo --samples 24
pcat-validate --config configs/enhanced_smoke.yaml --signer-independent
OMP_NUM_THREADS=1 pcat-train --config configs/enhanced_smoke.yaml
pcat-evaluate --checkpoint runs/enhanced_smoke_v2/best.pt --output evaluation/enhanced --max-new-tokens 8
pcat-predict --checkpoint runs/enhanced_smoke_v2/best.pt --pose data/demo/test_00000.npz --max-new-tokens 8
```

Dependency installation requires network access once; runtime does not download pretrained models or datasets. The demo's `hf`/`fh` references are **artificial event-order codes**, not sign-language utterances. Create a new data folder if the generator's output already exists. Training refuses to overwrite an existing `last.pt` without `--resume`; choose a new output directory for another experiment.

## Choose the regime deliberately

| File | Use |
|---|---|
| `configs/base.yaml` | Enhanced model: multiscale PCAT, progress augmentation, all-frame detail and physical timing; width 320 |
| `configs/invariant.yaml` | Coarse geometry-only model: exact polygonal refinement invariance under the stated assumptions; no detail memory or timing |
| `configs/enhanced_smoke.yaml` | Small complete enhanced training/generation run on generated geometric data |
| `configs/smoke.yaml` | Minimal coarse-only execution check |
| `configs/synthetic_order.yaml` | Longer coarse-only artificial-order sanity run |

Recommended base/invariant/enhanced-smoke configs integrate in float64 to reduce prefix-subtraction cancellation. Learned network weights remain float32. This trades integration memory and hardware-dependent speed for numerical precision. `integration: clipped` selects the explicit clipping alternative. `integration_precision: float32` is available when validated for your inputs.

The enhanced mode preserves durations and detail; **its complete output is not guaranteed speed or duplicate-frame invariant**. The invariant configuration uses a fixed first-frame reference, progress cells, no physical timing and no uncompressed frame attention. The fallback reference policy is useful in the enhanced mode but can change the chosen reference after resampling when the initial anchors are unreliable. These are explicit, different objectives.

## Real data

Provide JSONL manifests and NPZ arrays according to [docs/DATA.md](docs/DATA.md). Each pose must share a Euclidean coordinate frame across hands, face and torso. The default 66-joint interchange order is project-specific, not an asserted MediaPipe/OpenPose layout. Configure joint indices/regions for another dataset. Independently normalized local landmark coordinates do not satisfy the 3D geometry theorem.

```bash
pcat-validate --config configs/base.yaml --signer-independent
pcat-train --config configs/base.yaml
pcat-evaluate --checkpoint runs/pcat_v2/best.pt --manifest data/test.jsonl --output evaluation/pcat_v2
pcat-train --config configs/base.yaml --resume runs/pcat_v2/last.pt
```

Train and validation input files are fingerprinted; epoch-boundary resume restores optimizer, scheduler, scaler and RNG states and requires unchanged inputs/configuration apart from output directory. Exact resume is tested on CPU for both coarse and enhanced models, including dropout and partial accumulation groups.

Checkpoints now use **format version 2** because metric parameterization changed. Old checkpoints are rejected with an explicit message. In the working project, the original source archive is preserved under `releases/PCAT-SLT-v0.1.zip`, the initial whitepaper under `docs/history/`, and original results under `reports/v1/`. Existing historical run weights were not overwritten. The current source ZIP excludes release archives to avoid recursive packaging.

## Tests, experiments and evidence

- [reports/VERIFICATION.md](reports/VERIFICATION.md): current test results, numerical audit, measured benchmark and actual synthetic run.
- [docs/EXPERIMENTS.md](docs/EXPERIMENTS.md): matched internal/external comparisons and real-data study.
- [docs/LIMITATIONS.md](docs/LIMITATIONS.md): resolved defects, mitigations and unsolved requirements.

```bash
python scripts/mechanism_audit.py --output reports/mechanism_audit.json
python scripts/benchmark_operator.py --output reports/operator_benchmark.json
python scripts/run_ablations.py --config configs/invariant.yaml --seeds 17 23 41
```

The ablation script writes resolved configs; add `--execute` to train them sequentially. It includes identity transport, first-order, raw signature, temporal cells, Euclidean clock, toggled timing, single scale, removed progress augmentation and coarse-only memory. An unchanged option produces an equivalent control; select a suitable base regime. These are internal controls, not reproductions of every published baseline.

Evaluate generated text with corpus BLEU-1..4, chrF++, explicit macro ROUGE-L F1, exact match, EOS rate and invalid-UTF-8 rate. Invalid-byte constraints guarantee encoding validity, not grammaticality or meaning. Corpus metric signatures are saved. Paired confidence intervals are available through `scripts/paired_bootstrap.py`.

## Project structure

`src/pcat_slt/` contains geometry, exact integrators/transport, full model, strict config, datasets/collation, UTF-8 tokenizer/constraint, training, evaluation, inference, validation and reproducible runtime/checkpoint utilities. `tests/` covers mathematical properties and integration behavior; `configs/`, `docs/`, `reports/`, `scripts/` and CI complete the project.

There is no raw-video pose estimator, RGB appearance branch, pretrained language model, distributed trainer, mid-epoch resume or streaming guarantee. CPU and CUDA code paths are implemented; the reported verification is CPU-only, and MPS is not supported by this solve path. [docs/LIMITATIONS.md](docs/LIMITATIONS.md) explains which missing information or experiments would be needed to justify stronger claims.

All architecture files and releases stay inside this folder:

```bash
python scripts/package.py --output releases/PCAT-SLT.zip
```

Packaging excludes generated data, run weights, caches, environments and `releases/`. The ZIP contains a per-file SHA-256 manifest and has a companion archive checksum. `requirements-verified.txt` records the actual local CPU environment, not a universal cross-platform wheel lock.
