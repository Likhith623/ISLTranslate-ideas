"""Complete landmark-to-text network; PCAT is the only temporal compressor."""
import torch
from torch import Tensor, nn
from .config import ModelConfig
from .geometry import BodyFrame
from .operators import ProgressCoupledAreaTransport
from .tokenizer import ByteTokenizer


class SignTranslator(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        cfg.validate()
        self.cfg = cfg
        self.frame = BodyFrame(cfg.anchors, cfg.anchor_min_confidence)
        # Affine region maps preserve linear interpolation, unlike a pointwise MLP.
        self.region_maps = nn.ModuleList([nn.Linear(4 * len(r), cfg.rank) for r in cfg.regions])
        self.operator = ProgressCoupledAreaTransport(
            len(cfg.regions) * cfg.rank, cfg.bins, cfg.width, cfg.metric_floor,
            cfg.clock, cfg.operator, cfg.timing)
        self.source_position = nn.Parameter(torch.empty(1, cfg.bins, cfg.width))
        self.target_position = nn.Parameter(torch.empty(1, cfg.max_target_length, cfg.width))
        nn.init.normal_(self.source_position, std=0.02)
        nn.init.normal_(self.target_position, std=0.02)
        encoder_layer = nn.TransformerEncoderLayer(
            cfg.width, cfg.heads, cfg.width * cfg.ff_multiplier, cfg.dropout,
            activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(encoder_layer, cfg.encoder_layers,
                                             norm=nn.LayerNorm(cfg.width), enable_nested_tensor=False)
        decoder_layer = nn.TransformerDecoderLayer(
            cfg.width, cfg.heads, cfg.width * cfg.ff_multiplier, cfg.dropout,
            activation="gelu", batch_first=True, norm_first=True)
        self.decoder = nn.TransformerDecoder(decoder_layer, cfg.decoder_layers, norm=nn.LayerNorm(cfg.width))
        self.embedding = nn.Embedding(ByteTokenizer.vocab_size, cfg.width, padding_idx=0)
        self.output = nn.Linear(cfg.width, ByteTokenizer.vocab_size, bias=False)

    def embed_pose(self, pose: Tensor, confidence: Tensor, lengths: Tensor) -> Tensor:
        if pose.ndim != 4 or pose.shape[2:] != (self.cfg.joints, 3):
            raise ValueError("pose layout does not match config")
        if confidence.shape != pose.shape[:-1]:
            raise ValueError("confidence shape mismatch")
        b, t = pose.shape[:2]
        if lengths.shape != (b,) or lengths.dtype not in (torch.int32, torch.int64):
            raise ValueError("lengths must be an integer vector [B]")
        if ((lengths < 2) | (lengths > t)).any():
            raise ValueError("invalid sequence lengths")
        valid = torch.arange(t, device=pose.device)[None] < lengths[:, None]
        if not torch.isfinite(pose[valid]).all() or not torch.isfinite(confidence[valid]).all():
            raise ValueError("valid positions must be finite; impute missing joints in the loader")
        if ((confidence[valid] < 0) | (confidence[valid] > 1)).any():
            raise ValueError("confidence outside [0,1]")
        pose = torch.where(valid[..., None, None], pose, 0)
        confidence = torch.where(valid[..., None], confidence, 0)
        coords = self.frame(pose, confidence)
        features = torch.cat((coords, confidence[..., None]), dim=-1)
        blocks = [mapping(features[:, :, region].flatten(2))
                  for mapping, region in zip(self.region_maps, self.cfg.regions)]
        return torch.cat(blocks, dim=-1)

    def encode(self, pose: Tensor, confidence: Tensor, lengths: Tensor,
               timestamps: Tensor | None = None) -> Tensor:
        z = self.embed_pose(pose, confidence, lengths)
        tokens = self.operator(z, lengths, timestamps)
        return self.encoder(tokens + self.source_position)

    def decode(self, decoder_input: Tensor, memory: Tensor) -> Tensor:
        length = decoder_input.shape[1]
        if length < 1 or length > self.cfg.max_target_length:
            raise ValueError("decoder length outside configured bounds")
        hidden = self.embedding(decoder_input) + self.target_position[:, :length]
        causal = torch.ones(length, length, device=hidden.device, dtype=torch.bool).triu(1)
        hidden = self.decoder(hidden, memory, tgt_mask=causal,
                              tgt_key_padding_mask=decoder_input.eq(ByteTokenizer.pad_id))
        return self.output(hidden)

    def forward(self, pose, confidence, lengths, decoder_input, timestamps=None):
        return self.decode(decoder_input, self.encode(pose, confidence, lengths, timestamps))

    @torch.no_grad()
    def generate(self, pose, confidence, lengths, timestamps=None, max_new_tokens=None):
        if self.training:
            raise RuntimeError("call model.eval() before deterministic generation")
        limit = self.cfg.max_target_length if max_new_tokens is None else max_new_tokens
        if type(limit) is not int or not 1 <= limit <= self.cfg.max_target_length:
            raise ValueError("invalid generation length")
        memory = self.encode(pose, confidence, lengths, timestamps)
        ids = torch.full((pose.shape[0], 1), ByteTokenizer.bos_id, dtype=torch.long, device=pose.device)
        finished = torch.zeros(pose.shape[0], device=pose.device, dtype=torch.bool)
        for _ in range(limit):
            logits = self.decode(ids, memory)[:, -1]
            logits[:, :2] = -torch.inf
            next_id = logits.argmax(-1)
            next_id = torch.where(finished, ByteTokenizer.pad_id, next_id)
            ids = torch.cat((ids, next_id[:, None]), dim=1)
            finished = finished | next_id.eq(ByteTokenizer.eos_id)
            if finished.all():
                break
        return ids
