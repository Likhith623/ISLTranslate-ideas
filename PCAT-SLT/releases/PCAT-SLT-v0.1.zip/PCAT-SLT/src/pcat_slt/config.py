"""Strict configuration, shared by all entry points."""
from dataclasses import asdict, dataclass, field
from pathlib import Path
import math
import yaml


def default_regions():
    return [list(range(3, 24)), list(range(24, 45)), list(range(45, 63)), [0, 1, 2, 63, 64, 65]]


@dataclass
class ModelConfig:
    joints: int = 66
    anchors: list[int] = field(default_factory=lambda: [0, 1, 2])
    regions: list[list[int]] = field(default_factory=default_regions)
    rank: int = 4
    bins: int = 32
    width: int = 256
    heads: int = 8
    encoder_layers: int = 2
    decoder_layers: int = 4
    ff_multiplier: int = 4
    dropout: float = 0.1
    max_target_length: int = 512
    operator: str = "pcat"
    clock: str = "learned"
    timing: bool = False
    metric_floor: float = 0.05
    anchor_min_confidence: float = 0.5

    def validate(self):
        for name in ("joints", "rank", "bins", "width", "heads", "encoder_layers",
                     "decoder_layers", "ff_multiplier", "max_target_length"):
            value = getattr(self, name)
            if type(value) is not int or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.max_target_length < 2 or self.width % self.heads:
            raise ValueError("target length must be >=2 and width divisible by heads")
        if len(self.anchors) != 3 or len(set(self.anchors)) != 3:
            raise ValueError("anchors must be three distinct joints: left shoulder, right shoulder, neck")
        if not self.regions or any(not r for r in self.regions):
            raise ValueError("regions must contain nonempty joint lists")
        if any(type(j) is not int or j < 0 or j >= self.joints
               for j in self.anchors + [j for r in self.regions for j in r]):
            raise ValueError("joint index outside layout")
        if self.operator not in {"pcat", "signature", "first_order", "no_transport", "temporal"}:
            raise ValueError("unknown operator ablation")
        if self.clock not in {"learned", "euclidean"}:
            raise ValueError("clock must be learned or euclidean")
        if not math.isfinite(self.metric_floor) or self.metric_floor <= 0:
            raise ValueError("metric_floor must be finite and positive")
        if not 0 <= self.dropout < 1 or not 0 < self.anchor_min_confidence <= 1:
            raise ValueError("invalid dropout or anchor confidence threshold")


@dataclass
class DataConfig:
    train: str = "data/train.jsonl"
    val: str = "data/val.jsonl"
    test: str = "data/test.jsonl"
    batch_size: int = 8
    workers: int = 0
    max_frames: int = 1500
    max_bytes: int = 510


@dataclass
class TrainConfig:
    epochs: int = 50
    lr: float = 0.0003
    weight_decay: float = 0.01
    grad_clip: float = 1.0
    label_smoothing: float = 0.1
    accumulation: int = 1
    warmup_steps: int = 100
    seed: int = 17
    device: str = "auto"
    amp: bool = False
    deterministic: bool = True
    output_dir: str = "runs/pcat"


@dataclass
class Config:
    model: ModelConfig = field(default_factory=ModelConfig)
    data: DataConfig = field(default_factory=DataConfig)
    train: TrainConfig = field(default_factory=TrainConfig)

    def validate(self):
        self.model.validate()
        d, t = self.data, self.train
        if any(type(x) is not int or x < 1 for x in
               (d.batch_size, d.max_frames, d.max_bytes, t.epochs, t.accumulation)):
            raise ValueError("batch, frame, byte, epoch and accumulation limits must be positive integers")
        if d.max_frames < 2 or d.max_bytes + 1 > self.model.max_target_length:
            raise ValueError("max_frames must be >=2; max_bytes+1 must fit max_target_length")
        if any(type(x) is not int or x < 0 for x in (d.workers, t.warmup_steps, t.seed)):
            raise ValueError("workers, warmup_steps and seed must be nonnegative integers")
        if t.seed >= 2**32:
            raise ValueError("seed must fit NumPy's uint32 seed range")
        if any(not math.isfinite(x) for x in (t.lr, t.weight_decay, t.grad_clip, t.label_smoothing)):
            raise ValueError("training scalars must be finite")
        if t.lr <= 0 or t.weight_decay < 0 or t.grad_clip <= 0 or not 0 <= t.label_smoothing < 1:
            raise ValueError("invalid training scalars")
        if t.device not in {"auto", "cpu", "cuda"}:
            raise ValueError("supported devices: auto, cpu, cuda (PCAT uses torch.linalg.solve)")

    def to_dict(self):
        return asdict(self)


def from_dict(raw: dict) -> Config:
    if not isinstance(raw, dict) or set(raw) - {"model", "data", "train"}:
        raise ValueError("configuration must have only model, data, train sections")
    cfg = Config(ModelConfig(**raw.get("model", {})), DataConfig(**raw.get("data", {})),
                 TrainConfig(**raw.get("train", {})))
    cfg.validate()
    return cfg


def load_config(path: str | Path) -> Config:
    with Path(path).open(encoding="utf-8") as f:
        return from_dict(yaml.safe_load(f))
