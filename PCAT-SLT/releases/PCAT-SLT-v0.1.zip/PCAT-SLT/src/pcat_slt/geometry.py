"""Anatomically anchored SO(3)/translation/positive-scale canonicalization."""
import torch
from torch import Tensor, nn


class BodyFrame(nn.Module):
    """Use the FIRST frame's shoulders and neck; preserve subsequent torso motion.

    Coordinates must share one Euclidean 3D coordinate system. Reflections,
    perspective transformations, moving cameras and non-rigid scale are excluded.
    """

    def __init__(self, anchors=(0, 1, 2), min_confidence=0.5):
        super().__init__()
        self.anchors = tuple(anchors)
        self.min_confidence = min_confidence

    def forward(self, pose: Tensor, confidence: Tensor) -> Tensor:
        if pose.ndim != 4 or pose.shape[-1] != 3 or confidence.shape != pose.shape[:-1]:
            raise ValueError("expected pose [B,T,J,3] and confidence [B,T,J]")
        a = pose[:, 0, self.anchors, :]
        c = confidence[:, 0, self.anchors]
        if not torch.isfinite(a).all() or (c < self.min_confidence).any():
            raise ValueError("first frame needs three finite, reliable body anchors")
        left, right, neck = a.unbind(1)
        origin = (left + right) / 2
        shoulder = right - left
        width = torch.linalg.vector_norm(shoulder, dim=-1, keepdim=True)
        if (width <= 1e-8).any():
            raise ValueError("degenerate shoulder baseline")
        e1 = shoulder / width
        up = neck - origin
        up = up - (up * e1).sum(-1, keepdim=True) * e1
        height = torch.linalg.vector_norm(up, dim=-1, keepdim=True)
        if (height / width <= 1e-5).any():
            raise ValueError("neck collinear with shoulders")
        e2 = up / height
        e3 = torch.linalg.cross(e1, e2, dim=-1)
        basis = torch.stack((e1, e2, e3), dim=-1)
        centered = (pose - origin[:, None, None, :]) / width[:, None, None, :]
        return torch.einsum("btjc,bcd->btjd", centered, basis)
