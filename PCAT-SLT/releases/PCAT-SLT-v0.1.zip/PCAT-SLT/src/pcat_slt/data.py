"""Strict, variable-length JSONL/NPZ data loading and padded collation."""
import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset
from .config import ModelConfig, DataConfig
from .tokenizer import ByteTokenizer


def read_manifest(path: str | Path) -> list[dict]:
    path = Path(path).resolve()
    records, ids = [], set()
    with path.open(encoding="utf-8") as f:
        for line_number, line in enumerate(f, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if not isinstance(row, dict) or not {"id", "pose", "text"} <= row.keys():
                raise ValueError(f"{path}:{line_number}: required keys: id, pose, text")
            if not isinstance(row["id"], str) or not row["id"] or row["id"] in ids:
                raise ValueError(f"{path}:{line_number}: empty/duplicate/non-string id")
            if not isinstance(row["text"], str) or not row["text"].strip():
                raise ValueError(f"{path}:{line_number}: text must be a nonempty string")
            if not isinstance(row["pose"], str):
                raise ValueError("pose must be a filesystem path string")
            ids.add(row["id"])
            row["pose"] = str((path.parent / row["pose"]).resolve())
            records.append(row)
    if not records:
        raise ValueError(f"empty manifest: {path}")
    return records


def load_pose(path: str | Path, model: ModelConfig, max_frames: int) -> dict:
    with np.load(path, allow_pickle=False) as f:
        if not {"pose", "confidence", "timestamps"} <= set(f.files):
            raise ValueError(f"{path}: NPZ requires pose, confidence, timestamps")
        p = np.asarray(f["pose"], dtype=np.float32).copy()
        c = np.asarray(f["confidence"], dtype=np.float32).copy()
        ts = np.asarray(f["timestamps"], dtype=np.float64).copy()
    if p.ndim != 3 or p.shape[1:] != (model.joints, 3) or not 2 <= len(p) <= max_frames:
        raise ValueError(f"{path}: expected 2..{max_frames} frames with shape [T,{model.joints},3]")
    if c.shape != p.shape[:-1] or ts.shape != (len(p),):
        raise ValueError(f"{path}: confidence or timestamp shape mismatch")
    if not np.isfinite(c).all() or (c < 0).any() or (c > 1).any():
        raise ValueError(f"{path}: confidence must be finite in [0,1]")
    if not np.isfinite(ts).all() or (np.diff(ts) <= 0).any():
        raise ValueError(f"{path}: timestamps must be finite and strictly increasing, in seconds")
    if not np.isfinite(p[c > 0]).all():
        raise ValueError(f"{path}: observed coordinates must be finite")
    if (c[0, model.anchors] < model.anchor_min_confidence).any():
        raise ValueError(f"{path}: first-frame body anchors are unreliable")
    # Missing joints are interpolated in physical time, with nearest endpoint
    # extrapolation. Their confidence stays zero. Entirely absent joints sit at
    # the initial shoulder midpoint and are explicitly marked absent.
    origin = p[0, model.anchors[:2]].mean(0)
    for j in range(model.joints):
        observed = c[:, j] > 0
        if not observed.any():
            p[:, j] = origin
        elif not observed.all():
            for axis in range(3):
                p[:, j, axis] = np.interp(ts, ts[observed], p[observed, j, axis])
    ts = (ts - ts[0]).astype(np.float32)
    if (np.diff(ts) <= 0).any():
        raise ValueError(f"{path}: timestamp spacing is below float32 precision")
    return {"pose": torch.from_numpy(p), "confidence": torch.from_numpy(c),
            "timestamps": torch.from_numpy(ts)}


class SignDataset(Dataset):
    def __init__(self, manifest, model: ModelConfig, data: DataConfig):
        self.records = read_manifest(manifest)
        self.model, self.data = model, data
        self.tokenizer = ByteTokenizer()
        for row in self.records:
            if len(row["text"].encode("utf-8")) > data.max_bytes:
                raise ValueError(f"{row['id']}: target exceeds max_bytes; truncation is forbidden")

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        row = self.records[index]
        sample = load_pose(row["pose"], self.model, self.data.max_frames)
        sample.update(id=row["id"], text=row["text"],
                      tokens=torch.tensor(self.tokenizer.encode(row["text"]), dtype=torch.long))
        return sample


def collate_signs(samples: list[dict]) -> dict:
    if not samples:
        raise ValueError("cannot collate an empty batch")
    b = len(samples)
    lengths = torch.tensor([len(s["pose"]) for s in samples], dtype=torch.long)
    t, j = int(lengths.max()), samples[0]["pose"].shape[1]
    target_length = max(len(s["tokens"]) for s in samples)
    pose = torch.zeros(b, t, j, 3)
    confidence = torch.zeros(b, t, j)
    timestamps = torch.zeros(b, t)
    tokens = torch.full((b, target_length), ByteTokenizer.pad_id, dtype=torch.long)
    for i, sample in enumerate(samples):
        n, m = len(sample["pose"]), len(sample["tokens"])
        pose[i, :n] = sample["pose"]
        confidence[i, :n] = sample["confidence"]
        timestamps[i, :n] = sample["timestamps"]
        tokens[i, :m] = sample["tokens"]
    return {"pose": pose, "confidence": confidence, "timestamps": timestamps, "lengths": lengths,
            "decoder_input": tokens[:, :-1], "labels": tokens[:, 1:],
            "ids": [s["id"] for s in samples], "texts": [s["text"] for s in samples]}


def move_batch(batch: dict, device):
    return {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}


def assert_disjoint(datasets: dict[str, SignDataset]):
    seen_id, seen_path = {}, {}
    for split, dataset in datasets.items():
        for row in dataset.records:
            for value, seen, label in ((row["id"], seen_id, "id"), (row["pose"], seen_path, "path")):
                if value in seen:
                    raise ValueError(f"duplicate {label} across/within splits {seen[value]} and {split}: {value}")
                seen[value] = split
