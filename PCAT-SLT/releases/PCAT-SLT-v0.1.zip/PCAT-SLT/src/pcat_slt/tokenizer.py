"""Lossless UTF-8 byte targets: fixed vocabulary, no pretrained downloads."""
import torch


class ByteTokenizer:
    pad_id, bos_id, eos_id, vocab_size = 0, 1, 2, 259

    def encode(self, text: str) -> list[int]:
        return [self.bos_id] + [b + 3 for b in text.encode("utf-8")] + [self.eos_id]

    def decode(self, ids) -> str:
        if isinstance(ids, torch.Tensor):
            ids = ids.detach().cpu().tolist()
        result = []
        for token in ids:
            if token == self.eos_id:
                break
            if 3 <= token < self.vocab_size:
                result.append(token - 3)
        return bytes(result).decode("utf-8", errors="replace")
