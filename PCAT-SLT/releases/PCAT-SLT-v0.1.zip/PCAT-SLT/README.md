# PCAT-SLT

**Progress-Coupled Area Transport**: a complete PyTorch research implementation of a candidate operator for sign-language landmark-to-text translation.

PCAT converts cross-articulator chronological area into norm-preserving feature transport, using a shared learned progress clock. Its mathematical guarantees are specified and tested; its superiority on real sign-language translation benchmarks is **not established**. This is a runnable research codebase, not a pretrained interpreter or a guarantee of publication-level novelty.

## What you receive

- An implemented PCAT layer with exact clipping of polygonal motion segments, learned positive metric, signed areas and Cayley solves.
- A complete differentiable 3D-landmark-to-text encoder/decoder, trained from scratch without model downloads.
- Strict YAML configuration, JSONL/NPZ loaders, confidence-aware imputation and variable-length collation.
- Training with token-correct accumulation, optional CUDA AMP, cosine learning rates, validation, atomic checkpoints and exact CPU epoch-boundary resume tests.
- Greedy inference, corpus BLEU-1..4, chrF++, explicitly defined ROUGE-L, paired bootstrap and ablation configuration generation.
- Mathematical/gradient/data/training tests, CI, source packaging, a whitepaper, literature audit and an experiment protocol.

The input is **3D landmarks, confidence and timestamps** in a shared coordinate system. Raw video-to-pose extraction is external. The default 66-joint interchange layout is project-specific and documented in [docs/DATA.md](docs/DATA.md); changing `joints`, `anchors` and `regions` supports another layout. Do not feed an unrelated skeleton order or independently normalized hand/face coordinates into this configuration.

## Quick start

Use Python 3.10+ and run commands from the extracted `PCAT-SLT` root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
pytest -q
ruff check .

pcat-demo-data --output data/demo --samples 24
pcat-validate --config configs/smoke.yaml --signer-independent
OMP_NUM_THREADS=1 pcat-train --config configs/smoke.yaml
pcat-evaluate --checkpoint runs/smoke/best.pt --output evaluation/smoke --max-new-tokens 8
```

These commands require downloading Python dependencies once. They do not fetch sign corpora, pretrained backbones or pretrained text models. The generated `hf`/`fh` codes describe artificial geometric event order, not sign-language utterances. Eight smoke epochs verify execution and loss reduction; they are not intended to solve even that artificial task. A longer, fully specified sanity run is available:

```bash
OMP_NUM_THREADS=1 pcat-train --config configs/synthetic_order.yaml
pcat-evaluate --checkpoint runs/synthetic_order/best.pt --output evaluation/synthetic_order --max-new-tokens 8
pcat-predict --checkpoint runs/synthetic_order/best.pt --pose data/demo/test_00000.npz --max-new-tokens 8
```

Do not rerun the data generator into a populated directory. Training refuses to overwrite a directory containing `last.pt` unless resuming. For a fresh run, change `train.output_dir`. The source archive excludes generated data, run directories, environments, caches and weights.

## Training your corpus

1. Prepare the exact input contract in [docs/DATA.md](docs/DATA.md), including written-language targets and documented splits.
2. Edit `configs/base.yaml`: set manifests, joint layout, frame/target limits, batch size and output directory. `device: auto` selects CUDA when available, otherwise CPU. MPS is not supported by this implementation's linear algebra path.
3. Validate all samples, then train:

```bash
pcat-validate --config configs/base.yaml --signer-independent
pcat-train --config configs/base.yaml
pcat-evaluate --checkpoint runs/pcat/best.pt --manifest data/test.jsonl --output evaluation/pcat
```

To continue after an epoch checkpoint:

```bash
pcat-train --config configs/base.yaml --resume runs/pcat/last.pt
```

Resume requires identical configuration except `output_dir`, and identical training/validation manifests and source NPZ bytes. Optimizer, scheduler, scaler and random states are restored. Mid-epoch resume, distributed training and pretrained RGB/text modules are not implemented capabilities. CPU resume is tested for exact equality; hardware/library changes may change numerical results.

Generation uses a fixed UTF-8 byte vocabulary, with a causal decoder trained from scratch. This makes the project self-contained and keeps decoder changes out of the operator comparison, at the cost of longer sequences and no pretrained language knowledge. Invalid generated UTF-8 is decoded with replacement characters. Evaluate actual generated text, not teacher-forced logits.

## Mathematical core

Given shared progress-cell increments \(v_i\), their ordered signed area is

\[
H=\frac12\sum_{j<i}(v_jv_i^\top-v_iv_j^\top),\qquad
\widehat m=(I-A)^{-1}(I+A)m,\quad
A=\tanh(g)H/(1+\|H\|_F).
\]

The shared clock removes common parameterization changes while retaining some cross-channel chronological differences. Since A is skew-symmetric, transport preserves the value norm and the solve has condition number below \(\sqrt2\). These statements apply to the defined operation and assumptions, not to the entire network's training dynamics or translation accuracy. See [ARCHITECTURE.md](ARCHITECTURE.md) for equations and complete proofs.

`timing: false` is the invariant branch. `timing: true` appends duration and hold information and intentionally breaks full temporal invariance. Independent articulator timing invariance is not imposed. Constant proper 3D similarity invariance does not imply recovery from ambiguous 2D projection or arbitrary camera-dependent reconstruction.

## Research and verification

- [ARCHITECTURE.md](ARCHITECTURE.md): specification, proofs, complexity, ablation definitions and limitations.
- [docs/LITERATURE.md](docs/LITERATURE.md): targeted 2024–2026 review, older close antecedents and novelty claim ledger, with primary links.
- [docs/EXPERIMENTS.md](docs/EXPERIMENTS.md): matched real-corpus experiments and falsification criteria.
- [reports/VERIFICATION.md](reports/VERIFICATION.md): executed checks, measured numerical errors and actual synthetic-run outcomes.
- [reports/mechanism_audit.json](reports/mechanism_audit.json): machine-readable algebraic/event-order audit.

```bash
python scripts/mechanism_audit.py --output reports/mechanism_audit.json
python scripts/run_ablations.py --config configs/base.yaml --seeds 17 23 41
```

The ablation command writes configurations for PCAT, first-order, raw signature, identity transport, temporal cells, Euclidean clock and timing preservation. Add `--execute` to train them sequentially. It does not implement or claim to reproduce every external baseline in the literature. The primary scientific comparison is PCAT versus the same bounded-area representation without transport.

## Project map

```text
ARCHITECTURE.md            Equations, proofs and research claim boundaries
configs/                   Full, smoke and longer synthetic configurations
src/pcat_slt/
  geometry.py              Anatomical 3D canonicalization
  operators.py             PCAT primitive and exact polygonal integrals
  model.py                 Complete encoder, causal decoder and generation
  config.py                Strict dataclass configuration
  data.py                  Dataset, imputation, collation and split checks
  tokenizer.py             UTF-8 byte vocabulary
  train.py                 Optimization, validation, checkpoint resume
  evaluate.py              Autoregressive corpus metrics and predictions
  predict.py               Single-file inference
  metrics.py               SacreBLEU/chrF++ and explicit ROUGE-L
  runtime.py               RNG, hashing, metadata and checkpoint I/O
  validate.py              Full sample/content/signer validation
  synthetic.py             Nonlinguistic smoke-data generator
tests/                     Invariant, gradient and integration verification
scripts/                   Ablations, bootstrap, mechanism audit, packaging
docs/                      Literature, data contract and experiments
reports/                   Actual verification results, no invented SLT scores
```

Build a clean, deterministic source ZIP with per-file hashes:

```bash
python scripts/package.py --output releases/PCAT-SLT.zip
```

The archive includes a `MANIFEST.sha256.json`; a companion `.zip.sha256` verifies the complete archive. `requirements-verified.txt` records the exact packages used for the local CPU verification, rather than promising a universal cross-platform wheel lock. The broader dependency ranges in `pyproject.toml` support installation elsewhere. CUDA AMP has a functional implementation but was not exercised by the CPU verification reported here.
